import React, { Component } from 'react';

import Calendar from '../Calendar';
import './styles.css';

class App extends Component {
  render() {
    return (
      <div className="App">
        <Calendar/>
      </div>
    );
  }
}

export default App;
