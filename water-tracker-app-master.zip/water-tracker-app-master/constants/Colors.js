export default {
  primaryColor: '#0D110F',
  accentColorOrange: '#F9D88A',
  accentColorBlue: '#8DDBFC'
}