export const UPDATE_WATER_GOAL = 'UPDATE_WATER_GOAL';
export const ADJUST_WATER = 'ADJUST_WATER';
export const RESET_WATER = 'RESET_WATER';
export const APP_READY = 'APP_READY';