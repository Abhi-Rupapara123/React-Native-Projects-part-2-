module.exports = {
  extends: "handlebarlabs"
};
